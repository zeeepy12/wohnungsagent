# Wohnungsagent Bremen

## Einrichtung (ca. 15 Minuten)
1. Neues GitHub-Repo anlegen (öffentlich = unbegrenzt kostenlos; privat reicht bei 30-Minuten-Takt auch), alle Dateien hochladen (Ordnerstruktur beibehalten, inkl. `.github/workflows/`).
2. **Such-Alarme anlegen** (wichtigste Quelle): Auf ImmoScout24, Immowelt und Kleinanzeigen die Suche mit deinen Kriterien speichern und Mail-Benachrichtigung an dein Gmail-Postfach aktivieren.
3. **Gmail-App-Passwort** erstellen (Google-Konto > Sicherheit > 2-Schritt-Verifizierung > App-Passwörter). IMAP ist bei Gmail standardmäßig aktiv.
4. **Secrets** im Repo (Settings > Secrets and variables > Actions):
   - `ANTHROPIC_API_KEY` (von console.anthropic.com)
   - `SMTP_USER` (deine Gmail-Adresse)
   - `SMTP_PASSWORD` (das App-Passwort)
   - `MAIL_TO` (Adresse für die Benachrichtigungen)
5. **GEWOBA/Brebau**: Suche auf der Seite mit deinen Filtern öffnen, die URL der Ergebnisliste in `config.json` bei `seiten` eintragen.
6. Tab Actions > "Wohnungssuche" > Run workflow zum Testen.

## Hinweise
- Seiten, die ihre Inserate per JavaScript nachladen, liefern dem Skript evtl. keine Treffer. Dann bleibt der Mail-Alarm der zuverlässige Weg.
- Urteil "vielleicht" heißt: Kriterium unklar (z. B. nur Warmmiete oder keine Angabe zu Balkon).
- Kriterien änderst du in `config.json`.

## Bewerbungsentwurf (optional)
Lege ein weiteres Secret `BEWERBER_PROFIL` an (als Secret, damit deine Daten nicht öffentlich im Repo stehen).
Inhalt: frei formulierter Text, z. B. "Name: ...; Beruf: ...; Haushalt: ...; Haustiere: ...; Nichtraucher; 
Einzug gewünscht ab ...; Selbstauskunft auf Anfrage". Jeder Treffer mit Urteil "passt" bekommt dann
einen fertigen Entwurf in der Mail. Ohne das Secret wird kein Entwurf erstellt.
